Unicode
=======

.. doxygenfunction:: UnicodeLength
.. doxygenfunction:: DecodeUnicodeString
.. doxygenfunction:: DecodeUnicodeConsole
.. doxygenfunction:: DecodeUnicode
.. doxygenfunction:: EncodeUnicode
.. doxygenfunction:: ReadUnicodeFile
.. doxygenfunction:: CopyUnicodeString
.. doxygenfunction:: EncodeUTF8QuotedPrintable
.. doxygenfunction:: DecodeUTF8QuotedPrintable
.. doxygenfunction:: EncodeWithUTF8Alphabet
.. doxygenfunction:: DecodeWithUTF8Alphabet
.. doxygenfunction:: DecodeHexUnicode
.. doxygenfunction:: EncodeHexUnicode
.. doxygenfunction:: mywstrncmp
.. doxygenfunction:: mywstrstr
.. doxygenfunction:: mywstrncasecmp
.. doxygenfunction:: EncodeUTF8
.. doxygenfunction:: DecodeUTF8
.. doxygenfunction:: DecodeHexBin
.. doxygenfunction:: EncodeWithUnicodeAlphabet
.. doxygenfunction:: DecodeWithUnicodeAlphabet
