File
====

.. doxygenfunction:: GSM_JADFindData
.. doxygenfunction:: GSM_ReadFile
.. doxygenfunction:: GSM_IdentifyFileFormat
.. doxygenfunction:: GSM_GetNextFileFolder
.. doxygenfunction:: GSM_GetFolderListing
.. doxygenfunction:: GSM_GetNextRootFolder
.. doxygenfunction:: GSM_SetFileAttributes
.. doxygenfunction:: GSM_GetFilePart
.. doxygenfunction:: GSM_AddFilePart
.. doxygenfunction:: GSM_SendFilePart
.. doxygenfunction:: GSM_GetFileSystemStatus
.. doxygenfunction:: GSM_DeleteFile
.. doxygenfunction:: GSM_AddFolder
.. doxygenfunction:: GSM_DeleteFolder
.. doxygenstruct:: GSM_FileSystemStatus
.. doxygenenum:: GSM_FileType
.. doxygenstruct:: GSM_File
