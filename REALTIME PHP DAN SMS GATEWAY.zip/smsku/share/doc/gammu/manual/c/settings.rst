Settings
========

.. doxygenfunction:: GSM_GetLocale
.. doxygenfunction:: GSM_SetLocale
.. doxygenfunction:: GSM_GetSyncMLSettings
.. doxygenfunction:: GSM_SetSyncMLSettings
.. doxygenfunction:: GSM_GetChatSettings
.. doxygenfunction:: GSM_SetChatSettings
.. doxygenfunction:: GSM_GetMMSSettings
.. doxygenfunction:: GSM_SetMMSSettings
.. doxygenfunction:: GSM_SetAutoNetworkLogin
.. doxygenfunction:: GSM_Reset
.. doxygenfunction:: GSM_ResetPhoneSettings
.. doxygenfunction:: GSM_GetProfile
.. doxygenfunction:: GSM_SetProfile
.. doxygenfunction:: GSM_GetFMStation
.. doxygenfunction:: GSM_SetFMStation
.. doxygenfunction:: GSM_ClearFMStations
.. doxygenfunction:: GSM_GetGPRSAccessPoint
.. doxygenfunction:: GSM_SetGPRSAccessPoint
.. doxygenstruct:: GSM_SyncMLSettings
.. doxygenenum:: GSM_ResetSettingsType
.. doxygenstruct:: GSM_ChatSettings
.. doxygenenum:: GSM_Profile_Feat_Value
.. doxygenenum:: GSM_Profile_Feat_ID
.. doxygenstruct:: GSM_Profile
.. doxygenstruct:: GSM_FMStation
.. doxygenstruct:: GSM_GPRSAccessPoint
.. doxygenenum:: GSM_DateFormat
.. doxygenstruct:: GSM_Locale
.. doxygenstruct:: GSM_Profile_PhoneTableValue
